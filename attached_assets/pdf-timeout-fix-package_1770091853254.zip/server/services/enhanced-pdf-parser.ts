/**
 * Enhanced PDF Parsing Service
 * ============================
 * 
 * Handles large and complex PDFs with:
 * - Chunked processing for large documents
 * - Progress tracking and callbacks
 * - Automatic retry with exponential backoff
 * - Timeout management per chunk
 * - Graceful degradation for problem pages
 * 
 * INSTALLATION:
 *   Copy to: server/services/enhanced-pdf-parser.ts
 */

import Anthropic from '@anthropic-ai/sdk';
import { PDFDocument } from 'pdf-lib';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

// ============================================
// CONFIGURATION
// ============================================

export interface PDFParserConfig {
  /** Timeout per page in milliseconds (default: 30s) */
  timeoutPerPage: number;
  
  /** Maximum total timeout in milliseconds (default: 10 min) */
  maxTotalTimeout: number;
  
  /** Number of pages to process in each chunk (default: 3) */
  chunkSize: number;
  
  /** Maximum retries per chunk (default: 3) */
  maxRetries: number;
  
  /** Initial retry delay in ms (default: 2000) */
  initialRetryDelay: number;
  
  /** Max retry delay in ms (default: 30000) */
  maxRetryDelay: number;
  
  /** DPI for PDF to image conversion (default: 150) */
  imageDPI: number;
  
  /** JPEG quality for converted images (default: 85) */
  imageQuality: number;
  
  /** Maximum image dimension (default: 2000px) */
  maxImageDimension: number;
  
  /** Skip pages that fail after all retries (default: true) */
  skipFailedPages: boolean;
  
  /** Anthropic model to use */
  model: string;
}

const DEFAULT_CONFIG: PDFParserConfig = {
  timeoutPerPage: 30000,        // 30 seconds per page
  maxTotalTimeout: 600000,      // 10 minutes total
  chunkSize: 3,                 // Process 3 pages at a time
  maxRetries: 3,                // Retry failed chunks 3 times
  initialRetryDelay: 2000,      // Start with 2 second delay
  maxRetryDelay: 30000,         // Max 30 second delay
  imageDPI: 150,                // Good balance of quality/size
  imageQuality: 85,             // JPEG quality
  maxImageDimension: 2000,      // Max width/height
  skipFailedPages: true,        // Continue if some pages fail
  model: 'claude-sonnet-4-5',
};

// ============================================
// TYPE DEFINITIONS
// ============================================

export interface ParseProgress {
  stage: 'preparing' | 'converting' | 'analyzing' | 'merging' | 'complete' | 'error';
  currentPage: number;
  totalPages: number;
  currentChunk: number;
  totalChunks: number;
  percentComplete: number;
  message: string;
  estimatedTimeRemaining?: number;
}

export interface PageResult {
  pageNumber: number;
  success: boolean;
  data?: any;
  error?: string;
  retryCount: number;
  processingTime: number;
}

export interface ChunkResult {
  chunkIndex: number;
  pages: PageResult[];
  success: boolean;
  processingTime: number;
}

export interface ParseResult {
  success: boolean;
  data: any;
  pageResults: PageResult[];
  failedPages: number[];
  totalPages: number;
  processingTime: number;
  warnings: string[];
}

export type ProgressCallback = (progress: ParseProgress) => void;

// ============================================
// PDF INFO ANALYZER
// ============================================

export interface PDFInfo {
  pageCount: number;
  fileSizeBytes: number;
  fileSizeMB: number;
  isEncrypted: boolean;
  hasImages: boolean;
  estimatedComplexity: 'low' | 'medium' | 'high';
  estimatedProcessingTime: number;
  recommendedChunkSize: number;
  warnings: string[];
}

/**
 * Analyze PDF to determine processing strategy
 */
export async function analyzePDF(pdfBuffer: Buffer): Promise<PDFInfo> {
  const warnings: string[] = [];
  
  try {
    const pdfDoc = await PDFDocument.load(pdfBuffer, { 
      ignoreEncryption: true,
      updateMetadata: false,
    });
    
    const pageCount = pdfDoc.getPageCount();
    const fileSizeBytes = pdfBuffer.length;
    const fileSizeMB = fileSizeBytes / (1024 * 1024);
    
    // Check for encryption
    let isEncrypted = false;
    try {
      // If we can access pages, it's not encrypted (or encryption is ignored)
      pdfDoc.getPage(0);
    } catch {
      isEncrypted = true;
      warnings.push('PDF appears to be encrypted');
    }
    
    // Estimate complexity based on file size per page
    const bytesPerPage = fileSizeBytes / pageCount;
    let estimatedComplexity: 'low' | 'medium' | 'high';
    
    if (bytesPerPage < 100000) {
      estimatedComplexity = 'low';  // < 100KB per page (mostly text)
    } else if (bytesPerPage < 500000) {
      estimatedComplexity = 'medium';  // 100-500KB per page (some images)
    } else {
      estimatedComplexity = 'high';  // > 500KB per page (image-heavy)
      warnings.push('PDF appears to be image-heavy, processing may be slower');
    }
    
    // Estimate processing time (rough: 10s low, 20s medium, 30s high per page)
    const timePerPage = {
      low: 10000,
      medium: 20000,
      high: 30000,
    };
    const estimatedProcessingTime = pageCount * timePerPage[estimatedComplexity];
    
    // Recommend chunk size based on complexity
    const recommendedChunkSize = {
      low: 5,
      medium: 3,
      high: 2,
    };
    
    // Add warnings for large documents
    if (pageCount > 20) {
      warnings.push(`Large document (${pageCount} pages) - processing may take several minutes`);
    }
    if (fileSizeMB > 10) {
      warnings.push(`Large file (${fileSizeMB.toFixed(1)}MB) - consider splitting into smaller files`);
    }
    
    return {
      pageCount,
      fileSizeBytes,
      fileSizeMB,
      isEncrypted,
      hasImages: estimatedComplexity !== 'low',
      estimatedComplexity,
      estimatedProcessingTime,
      recommendedChunkSize: recommendedChunkSize[estimatedComplexity],
      warnings,
    };
  } catch (error) {
    throw new Error(`Failed to analyze PDF: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

// ============================================
// PDF TO IMAGE CONVERSION
// ============================================

interface ConvertedPage {
  pageNumber: number;
  imagePath: string;
  base64: string;
  width: number;
  height: number;
}

/**
 * Convert PDF pages to images using pdftoppm (poppler)
 */
async function convertPDFToImages(
  pdfBuffer: Buffer,
  startPage: number,
  endPage: number,
  config: PDFParserConfig
): Promise<ConvertedPage[]> {
  const tempDir = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'pdf-parse-'));
  const pdfPath = path.join(tempDir, 'input.pdf');
  
  try {
    // Write PDF to temp file
    await fs.promises.writeFile(pdfPath, pdfBuffer);
    
    // Convert specific pages to JPEG
    const outputPrefix = path.join(tempDir, 'page');
    await execAsync(
      `pdftoppm -jpeg -jpegopt quality=${config.imageQuality} ` +
      `-r ${config.imageDPI} ` +
      `-f ${startPage} -l ${endPage} ` +
      `-scale-to ${config.maxImageDimension} ` +
      `"${pdfPath}" "${outputPrefix}"`,
      { timeout: config.timeoutPerPage * (endPage - startPage + 1) }
    );
    
    // Read converted images
    const pages: ConvertedPage[] = [];
    
    for (let pageNum = startPage; pageNum <= endPage; pageNum++) {
      // pdftoppm naming: page-01.jpg, page-02.jpg, etc.
      const paddedNum = String(pageNum).padStart(String(endPage).length, '0');
      const imagePath = `${outputPrefix}-${paddedNum}.jpg`;
      
      // Check if file exists (some pages might fail)
      try {
        const imageBuffer = await fs.promises.readFile(imagePath);
        const base64 = imageBuffer.toString('base64');
        
        // Get image dimensions (rough estimate from file size)
        // In production, use sharp or similar for actual dimensions
        const width = config.maxImageDimension;
        const height = config.maxImageDimension;
        
        pages.push({
          pageNumber: pageNum,
          imagePath,
          base64,
          width,
          height,
        });
      } catch {
        console.warn(`Could not read converted image for page ${pageNum}`);
      }
    }
    
    return pages;
  } finally {
    // Cleanup temp files
    try {
      await fs.promises.rm(tempDir, { recursive: true, force: true });
    } catch {
      console.warn('Could not cleanup temp directory:', tempDir);
    }
  }
}

/**
 * Fallback: Convert using pdf-lib and canvas (if pdftoppm not available)
 */
async function convertPDFToImagesNodeOnly(
  pdfBuffer: Buffer,
  startPage: number,
  endPage: number,
  config: PDFParserConfig
): Promise<ConvertedPage[]> {
  // This is a simplified fallback - in production, use pdf2pic or similar
  const pdfDoc = await PDFDocument.load(pdfBuffer);
  const pages: ConvertedPage[] = [];
  
  for (let i = startPage - 1; i < endPage && i < pdfDoc.getPageCount(); i++) {
    const page = pdfDoc.getPage(i);
    const { width, height } = page.getSize();
    
    // For this fallback, we'll pass the raw PDF page info
    // The actual image conversion would require additional libraries
    pages.push({
      pageNumber: i + 1,
      imagePath: '',
      base64: '', // Would need pdf2pic or puppeteer for actual conversion
      width,
      height,
    });
  }
  
  return pages;
}

// ============================================
// AI EXTRACTION WITH RETRY
// ============================================

/**
 * Extract data from page images using Claude with retry logic
 */
async function extractFromImages(
  anthropic: Anthropic,
  images: ConvertedPage[],
  extractionPrompt: string,
  config: PDFParserConfig
): Promise<{ data: any; rawResponse: string }> {
  const imageContents = images.map(img => ({
    type: 'image' as const,
    source: {
      type: 'base64' as const,
      media_type: 'image/jpeg' as const,
      data: img.base64,
    },
  }));
  
  const response = await anthropic.messages.create({
    model: config.model,
    max_tokens: 8192,
    messages: [{
      role: 'user',
      content: [
        {
          type: 'text',
          text: extractionPrompt,
        },
        ...imageContents,
      ],
    }],
  });
  
  const rawResponse = response.content[0].type === 'text' 
    ? response.content[0].text 
    : '';
  
  // Try to parse as JSON
  let data: any;
  try {
    // Find JSON in response (might be wrapped in markdown)
    const jsonMatch = rawResponse.match(/```json\s*([\s\S]*?)\s*```/) ||
                      rawResponse.match(/\{[\s\S]*\}/);
    const jsonStr = jsonMatch ? jsonMatch[1] || jsonMatch[0] : rawResponse;
    data = JSON.parse(jsonStr);
  } catch {
    // Return raw response if not valid JSON
    data = { rawText: rawResponse };
  }
  
  return { data, rawResponse };
}

/**
 * Process a chunk with retry logic
 */
async function processChunkWithRetry(
  anthropic: Anthropic,
  pdfBuffer: Buffer,
  startPage: number,
  endPage: number,
  extractionPrompt: string,
  config: PDFParserConfig,
  onProgress?: ProgressCallback
): Promise<ChunkResult> {
  const startTime = Date.now();
  const pageResults: PageResult[] = [];
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt <= config.maxRetries; attempt++) {
    try {
      // Convert pages to images
      const images = await convertPDFToImages(pdfBuffer, startPage, endPage, config);
      
      if (images.length === 0) {
        throw new Error('No images converted from PDF pages');
      }
      
      // Extract data from images
      const { data } = await extractFromImages(
        anthropic,
        images,
        extractionPrompt,
        config
      );
      
      // Success - record results for each page
      for (let pageNum = startPage; pageNum <= endPage; pageNum++) {
        pageResults.push({
          pageNumber: pageNum,
          success: true,
          data: pageNum === startPage ? data : undefined, // Data is for the chunk
          retryCount: attempt,
          processingTime: Date.now() - startTime,
        });
      }
      
      return {
        chunkIndex: Math.floor((startPage - 1) / config.chunkSize),
        pages: pageResults,
        success: true,
        processingTime: Date.now() - startTime,
      };
      
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      
      // Check if we should retry
      if (attempt < config.maxRetries) {
        const delay = Math.min(
          config.initialRetryDelay * Math.pow(2, attempt),
          config.maxRetryDelay
        );
        
        console.log(`Chunk ${startPage}-${endPage} failed (attempt ${attempt + 1}), retrying in ${delay}ms...`);
        
        onProgress?.({
          stage: 'analyzing',
          currentPage: startPage,
          totalPages: endPage,
          currentChunk: Math.floor((startPage - 1) / config.chunkSize),
          totalChunks: Math.ceil(endPage / config.chunkSize),
          percentComplete: 0,
          message: `Retrying pages ${startPage}-${endPage} (attempt ${attempt + 2}/${config.maxRetries + 1})`,
        });
        
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  // All retries failed
  for (let pageNum = startPage; pageNum <= endPage; pageNum++) {
    pageResults.push({
      pageNumber: pageNum,
      success: false,
      error: lastError?.message || 'Unknown error',
      retryCount: config.maxRetries,
      processingTime: Date.now() - startTime,
    });
  }
  
  return {
    chunkIndex: Math.floor((startPage - 1) / config.chunkSize),
    pages: pageResults,
    success: false,
    processingTime: Date.now() - startTime,
  };
}

// ============================================
// MAIN PARSER CLASS
// ============================================

export class EnhancedPDFParser {
  private anthropic: Anthropic;
  private config: PDFParserConfig;
  
  constructor(
    anthropicClient: Anthropic,
    config: Partial<PDFParserConfig> = {}
  ) {
    this.anthropic = anthropicClient;
    this.config = { ...DEFAULT_CONFIG, ...config };
  }
  
  /**
   * Parse a PDF with progress tracking
   */
  async parse(
    pdfBuffer: Buffer,
    extractionPrompt: string,
    onProgress?: ProgressCallback
  ): Promise<ParseResult> {
    const startTime = Date.now();
    const warnings: string[] = [];
    
    // Stage 1: Analyze PDF
    onProgress?.({
      stage: 'preparing',
      currentPage: 0,
      totalPages: 0,
      currentChunk: 0,
      totalChunks: 0,
      percentComplete: 0,
      message: 'Analyzing PDF...',
    });
    
    const pdfInfo = await analyzePDF(pdfBuffer);
    warnings.push(...pdfInfo.warnings);
    
    const totalPages = pdfInfo.pageCount;
    const chunkSize = Math.min(this.config.chunkSize, pdfInfo.recommendedChunkSize);
    const totalChunks = Math.ceil(totalPages / chunkSize);
    
    // Check total timeout feasibility
    if (pdfInfo.estimatedProcessingTime > this.config.maxTotalTimeout) {
      warnings.push(
        `Estimated processing time (${Math.round(pdfInfo.estimatedProcessingTime / 60000)} min) ` +
        `exceeds timeout (${Math.round(this.config.maxTotalTimeout / 60000)} min). ` +
        `Some pages may not be processed.`
      );
    }
    
    // Stage 2: Process chunks
    const allPageResults: PageResult[] = [];
    const chunkData: any[] = [];
    let processedPages = 0;
    
    for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
      const startPage = chunkIndex * chunkSize + 1;
      const endPage = Math.min(startPage + chunkSize - 1, totalPages);
      
      // Check total timeout
      if (Date.now() - startTime > this.config.maxTotalTimeout) {
        warnings.push(`Processing stopped at page ${startPage} due to total timeout`);
        
        // Mark remaining pages as skipped
        for (let pageNum = startPage; pageNum <= totalPages; pageNum++) {
          allPageResults.push({
            pageNumber: pageNum,
            success: false,
            error: 'Skipped due to total timeout',
            retryCount: 0,
            processingTime: 0,
          });
        }
        break;
      }
      
      // Update progress
      const percentComplete = Math.round((processedPages / totalPages) * 100);
      const elapsed = Date.now() - startTime;
      const estimatedRemaining = processedPages > 0
        ? (elapsed / processedPages) * (totalPages - processedPages)
        : pdfInfo.estimatedProcessingTime;
      
      onProgress?.({
        stage: 'analyzing',
        currentPage: startPage,
        totalPages,
        currentChunk: chunkIndex + 1,
        totalChunks,
        percentComplete,
        message: `Processing pages ${startPage}-${endPage} of ${totalPages}`,
        estimatedTimeRemaining: estimatedRemaining,
      });
      
      // Process chunk
      const chunkResult = await processChunkWithRetry(
        this.anthropic,
        pdfBuffer,
        startPage,
        endPage,
        extractionPrompt,
        this.config,
        onProgress
      );
      
      allPageResults.push(...chunkResult.pages);
      
      if (chunkResult.success) {
        // Extract data from successful chunk
        const successfulPage = chunkResult.pages.find(p => p.success && p.data);
        if (successfulPage?.data) {
          chunkData.push(successfulPage.data);
        }
      } else if (!this.config.skipFailedPages) {
        // Fail fast if configured
        throw new Error(`Failed to process pages ${startPage}-${endPage} after ${this.config.maxRetries} retries`);
      } else {
        warnings.push(`Pages ${startPage}-${endPage} could not be processed`);
      }
      
      processedPages += (endPage - startPage + 1);
    }
    
    // Stage 3: Merge results
    onProgress?.({
      stage: 'merging',
      currentPage: totalPages,
      totalPages,
      currentChunk: totalChunks,
      totalChunks,
      percentComplete: 95,
      message: 'Merging extracted data...',
    });
    
    const mergedData = this.mergeChunkData(chunkData);
    
    // Stage 4: Complete
    const failedPages = allPageResults
      .filter(p => !p.success)
      .map(p => p.pageNumber);
    
    const processingTime = Date.now() - startTime;
    
    onProgress?.({
      stage: 'complete',
      currentPage: totalPages,
      totalPages,
      currentChunk: totalChunks,
      totalChunks,
      percentComplete: 100,
      message: failedPages.length > 0
        ? `Completed with ${failedPages.length} failed pages`
        : 'Processing complete',
    });
    
    return {
      success: failedPages.length < totalPages, // Success if we got some data
      data: mergedData,
      pageResults: allPageResults,
      failedPages,
      totalPages,
      processingTime,
      warnings,
    };
  }
  
  /**
   * Merge data from multiple chunks
   */
  private mergeChunkData(chunkData: any[]): any {
    if (chunkData.length === 0) {
      return null;
    }
    
    if (chunkData.length === 1) {
      return chunkData[0];
    }
    
    // Deep merge chunk data
    // This is a simple implementation - customize based on your data structure
    const merged: any = {};
    
    for (const chunk of chunkData) {
      if (!chunk || typeof chunk !== 'object') continue;
      
      for (const [key, value] of Object.entries(chunk)) {
        if (merged[key] === undefined) {
          merged[key] = value;
        } else if (Array.isArray(merged[key]) && Array.isArray(value)) {
          // Merge arrays
          merged[key] = [...merged[key], ...value];
        } else if (typeof merged[key] === 'number' && typeof value === 'number') {
          // Sum numbers (for things like totals)
          merged[key] = merged[key] + value;
        } else if (typeof merged[key] === 'object' && typeof value === 'object') {
          // Recursively merge objects
          merged[key] = { ...merged[key], ...value };
        }
        // For other cases, keep the first value
      }
    }
    
    return merged;
  }
  
  /**
   * Update configuration
   */
  updateConfig(config: Partial<PDFParserConfig>): void {
    this.config = { ...this.config, ...config };
  }
  
  /**
   * Get current configuration
   */
  getConfig(): PDFParserConfig {
    return { ...this.config };
  }
}

// ============================================
// FACTORY FUNCTION
// ============================================

/**
 * Create an enhanced PDF parser instance
 */
export function createEnhancedPDFParser(
  anthropicClient: Anthropic,
  config?: Partial<PDFParserConfig>
): EnhancedPDFParser {
  return new EnhancedPDFParser(anthropicClient, config);
}

export default EnhancedPDFParser;
