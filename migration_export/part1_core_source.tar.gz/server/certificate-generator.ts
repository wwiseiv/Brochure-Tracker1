import { PDFDocument, rgb, StandardFonts } from "pdf-lib";
import { storage } from "./storage";
import fs from 'fs';
import path from 'path';

export interface CertificateData {
  recipientName: string;
  certificateType: string;
  title: string;
  description: string;
  issuedDate: string;
  verificationCode: string;
}

export const CERTIFICATE_TYPES = {
  presentation_mastery: {
    title: "Presentation Mastery Certificate",
    description: "Has demonstrated mastery of the PCBancard Dual Pricing Presentation through completion of all 8 training modules, 24 lessons, and achieving passing scores on all assessments.",
    requirement: "Complete all 24 presentation training lessons",
  },
  equipiq_expert: {
    title: "Equipment Expert Certificate",
    description: "Has demonstrated comprehensive knowledge of payment processing equipment through successful completion of EquipIQ assessment program.",
    requirement: "Complete 20+ EquipIQ quizzes with 80%+ average score",
  },
  roleplay_champion: {
    title: "Roleplay Champion Certificate",
    description: "Has demonstrated exceptional sales conversation skills through extensive practice in AI-powered roleplay sessions.",
    requirement: "Complete 30+ roleplay sessions with 75+ average performance score",
  },
  sales_excellence: {
    title: "Sales Excellence Certificate",
    description: "Has achieved the highest level of sales training proficiency across all PCBancard training programs, demonstrating mastery in presentations, equipment knowledge, and sales conversations.",
    requirement: "Earn Gold badge or higher in 3+ categories",
  },
  ladder_field_scout: {
    title: "Certificate of Achievement: Field Scout",
    description: "Has earned the Field Scout progression level, demonstrating foundational sales skills and commitment to the PCBancard training program.",
    requirement: "Earned Field Scout badge",
  },
  ladder_pipeline_builder: {
    title: "Certificate of Achievement: Pipeline Builder",
    description: "Has earned the Pipeline Builder progression level, demonstrating growing expertise in building and managing a sales pipeline.",
    requirement: "Earned Pipeline Builder badge",
  },
  ladder_deal_closer: {
    title: "Certificate of Achievement: Deal Closer",
    description: "Has earned the Deal Closer progression level, demonstrating proven ability to close deals and deliver results.",
    requirement: "Earned Deal Closer badge",
  },
  ladder_revenue_generator: {
    title: "Certificate of Achievement: Revenue Generator",
    description: "Has earned the Revenue Generator progression level, demonstrating consistent revenue generation and advanced sales proficiency.",
    requirement: "Earned Revenue Generator badge",
  },
  ladder_residual_architect: {
    title: "Certificate of Mastery: Residual Architect",
    description: "Has achieved the highest progression level — Residual Architect — demonstrating mastery across all PCBancard sales disciplines and the ability to build lasting residual income.",
    requirement: "Earned Residual Architect badge",
  },
};

const LADDER_CERT_TYPES = new Set([
  'ladder_field_scout',
  'ladder_pipeline_builder',
  'ladder_deal_closer',
  'ladder_revenue_generator',
  'ladder_residual_architect',
]);

function isLadderCertificate(certType: string): boolean {
  return LADDER_CERT_TYPES.has(certType);
}

export async function generateCertificatePDF(data: CertificateData): Promise<Buffer> {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([792, 612]);
  const { width, height } = page.getSize();

  const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const helvetica = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const timesRomanItalic = await pdfDoc.embedFont(StandardFonts.TimesRomanItalic);

  const isLadder = isLadderCertificate(data.certificateType);
  const accentColor = isLadder ? rgb(0.29, 0.27, 0.63) : rgb(0.18, 0.33, 0.59);
  const ornamentColor = isLadder ? rgb(0.55, 0.48, 0.78) : rgb(0.72, 0.65, 0.45);

  page.drawRectangle({
    x: 0, y: 0, width, height,
    color: isLadder ? rgb(0.96, 0.95, 0.98) : rgb(0.98, 0.97, 0.94),
  });

  const borderWidth = 3;
  const margin = 30;
  page.drawRectangle({
    x: margin, y: margin,
    width: width - 2 * margin,
    height: height - 2 * margin,
    borderColor: accentColor,
    borderWidth,
  });

  page.drawRectangle({
    x: margin + 8, y: margin + 8,
    width: width - 2 * (margin + 8),
    height: height - 2 * (margin + 8),
    borderColor: ornamentColor,
    borderWidth: 1.5,
  });

  const headerText = "PCBANCARD";
  const headerSize = 16;
  const headerWidth = helveticaBold.widthOfTextAtSize(headerText, headerSize);
  page.drawText(headerText, {
    x: (width - headerWidth) / 2,
    y: height - 80,
    size: headerSize,
    font: helveticaBold,
    color: accentColor,
  });

  const certTitle = data.certificateType === 'ladder_residual_architect'
    ? "Certificate of Mastery"
    : isLadder
      ? "Certificate of Achievement"
      : "Certificate of Achievement";
  const certTitleSize = 28;
  const certTitleWidth = helveticaBold.widthOfTextAtSize(certTitle, certTitleSize);
  page.drawText(certTitle, {
    x: (width - certTitleWidth) / 2,
    y: height - 125,
    size: certTitleSize,
    font: helveticaBold,
    color: accentColor,
  });

  page.drawLine({
    start: { x: 150, y: height - 140 },
    end: { x: width - 150, y: height - 140 },
    thickness: 1.5,
    color: ornamentColor,
  });

  const certifiesText = "This certifies that";
  const certifiesSize = 14;
  const certifiesWidth = timesRomanItalic.widthOfTextAtSize(certifiesText, certifiesSize);
  page.drawText(certifiesText, {
    x: (width - certifiesWidth) / 2,
    y: height - 180,
    size: certifiesSize,
    font: timesRomanItalic,
    color: rgb(0.3, 0.3, 0.3),
  });

  const nameSize = 32;
  const nameWidth = helveticaBold.widthOfTextAtSize(data.recipientName, nameSize);
  page.drawText(data.recipientName, {
    x: (width - nameWidth) / 2,
    y: height - 225,
    size: nameSize,
    font: helveticaBold,
    color: rgb(0.1, 0.1, 0.1),
  });

  page.drawLine({
    start: { x: 150, y: height - 235 },
    end: { x: width - 150, y: height - 235 },
    thickness: 0.8,
    color: rgb(0.5, 0.5, 0.5),
  });

  const awardTitleSize = 20;
  const awardTitleWidth = helveticaBold.widthOfTextAtSize(data.title, awardTitleSize);
  page.drawText(data.title, {
    x: (width - awardTitleWidth) / 2,
    y: height - 280,
    size: awardTitleSize,
    font: helveticaBold,
    color: accentColor,
  });

  const descSize = 11;
  const maxLineWidth = width - 200;
  const descWords = data.description.split(' ');
  let lines: string[] = [];
  let currentLine = '';

  for (const word of descWords) {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    const testWidth = helvetica.widthOfTextAtSize(testLine, descSize);
    if (testWidth > maxLineWidth) {
      lines.push(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  }
  if (currentLine) lines.push(currentLine);

  let yPos = height - 320;
  for (const line of lines) {
    const lineWidth = helvetica.widthOfTextAtSize(line, descSize);
    page.drawText(line, {
      x: (width - lineWidth) / 2,
      y: yPos,
      size: descSize,
      font: helvetica,
      color: rgb(0.3, 0.3, 0.3),
    });
    yPos -= 18;
  }

  const dateText = `Issued: ${data.issuedDate}`;
  const dateSize = 11;
  const dateWidth = helvetica.widthOfTextAtSize(dateText, dateSize);
  page.drawText(dateText, {
    x: (width - dateWidth) / 2,
    y: 100,
    size: dateSize,
    font: helvetica,
    color: rgb(0.4, 0.4, 0.4),
  });

  const verifyText = `Verification: ${data.verificationCode}`;
  const verifySize = 9;
  const verifyWidth = helvetica.widthOfTextAtSize(verifyText, verifySize);
  page.drawText(verifyText, {
    x: (width - verifyWidth) / 2,
    y: 70,
    size: verifySize,
    font: helvetica,
    color: rgb(0.5, 0.5, 0.5),
  });

  const pdfBytes = await pdfDoc.save();
  return Buffer.from(pdfBytes);
}

export interface VisualCertificateData {
  recipientName: string;
  certificateTitle: string;
  description: string;
  primaryAssetId: string;
  secondaryAssetIds?: string[];
  issuedBy: string;
  verificationCode: string;
}

function resolveAssetFile(assetId: string): string {
  const manifestPath = path.join(process.cwd(), 'public', 'certificates', 'certificate-assets.json');
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
  const asset = manifest.assets[assetId];
  if (!asset) throw new Error(`Unknown assetId: ${assetId}`);
  return path.join(process.cwd(), 'public', 'certificates', asset.file);
}

export async function generateVisualCertificatePDF(data: VisualCertificateData): Promise<Buffer> {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([792, 612]);
  const { width, height } = page.getSize();

  const helvetica = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const timesRomanBold = await pdfDoc.embedFont(StandardFonts.TimesRomanBold);
  const timesRomanBoldItalic = await pdfDoc.embedFont(StandardFonts.TimesRomanBoldItalic);

  try {
    const borderPath = path.join(process.cwd(), 'public', 'certificates', 'borders', 'certificate-border-template.png');
    if (fs.existsSync(borderPath)) {
      const borderImageBytes = fs.readFileSync(borderPath);
      const borderImage = await pdfDoc.embedPng(borderImageBytes);
      page.drawImage(borderImage, {
        x: 0,
        y: 0,
        width: width,
        height: height,
      });
    }
  } catch (e) {
    // Gracefully handle missing border template
  }

  page.drawText('PCBancard Field Sales Intelligence Suite', {
    x: (width - helvetica.widthOfTextAtSize('PCBancard Field Sales Intelligence Suite', 11)) / 2,
    y: height - 95,
    size: 11,
    font: helvetica,
    color: rgb(0.39, 0.4, 0.95),
  });

  page.drawText('CERTIFICATE OF ACHIEVEMENT', {
    x: (width - timesRomanBold.widthOfTextAtSize('CERTIFICATE OF ACHIEVEMENT', 22)) / 2,
    y: height - 130,
    size: 22,
    font: timesRomanBold,
    color: rgb(0.12, 0.23, 0.37),
  });

  const certifiesText = 'This certifies that';
  page.drawText(certifiesText, {
    x: (width - timesRomanBoldItalic.widthOfTextAtSize(certifiesText, 13)) / 2,
    y: height - 165,
    size: 13,
    font: timesRomanBoldItalic,
    color: rgb(0.42, 0.42, 0.42),
  });

  page.drawText(data.recipientName, {
    x: (width - timesRomanBold.widthOfTextAtSize(data.recipientName, 28)) / 2,
    y: height - 200,
    size: 28,
    font: timesRomanBold,
    color: rgb(0.12, 0.23, 0.37),
  });

  page.drawLine({
    start: { x: (width - 300) / 2, y: height - 210 },
    end: { x: (width + 300) / 2, y: height - 210 },
    thickness: 1,
    color: rgb(0.96, 0.62, 0.04),
  });

  const achievedText = 'has successfully achieved the designation of';
  page.drawText(achievedText, {
    x: (width - timesRomanBoldItalic.widthOfTextAtSize(achievedText, 13)) / 2,
    y: height - 235,
    size: 13,
    font: timesRomanBoldItalic,
    color: rgb(0.42, 0.42, 0.42),
  });

  page.drawText(data.certificateTitle, {
    x: (width - timesRomanBold.widthOfTextAtSize(data.certificateTitle, 20)) / 2,
    y: height - 265,
    size: 20,
    font: timesRomanBold,
    color: rgb(0.96, 0.62, 0.04),
  });

  try {
    const primaryAssetPath = resolveAssetFile(data.primaryAssetId);
    if (fs.existsSync(primaryAssetPath)) {
      const primaryImageBytes = fs.readFileSync(primaryAssetPath);
      const primaryImage = await pdfDoc.embedPng(primaryImageBytes);
      const medallionSize = 120;
      const medallionX = (width - medallionSize) / 2;
      const medallionY = height - 405;
      page.drawImage(primaryImage, {
        x: medallionX,
        y: medallionY,
        width: medallionSize,
        height: medallionSize,
      });

      let sealX = medallionX + medallionSize + 10;
      if (data.secondaryAssetIds && data.secondaryAssetIds.length > 0) {
        for (const sealId of data.secondaryAssetIds) {
          try {
            const sealPath = resolveAssetFile(sealId);
            if (fs.existsSync(sealPath)) {
              const sealImageBytes = fs.readFileSync(sealPath);
              const sealImage = await pdfDoc.embedPng(sealImageBytes);
              const sealSize = 60;
              page.drawImage(sealImage, {
                x: sealX,
                y: medallionY + (medallionSize - sealSize) / 2,
                width: sealSize,
                height: sealSize,
              });
              sealX += sealSize + 10;
            }
          } catch (e) {
            // Gracefully skip missing secondary assets
          }
        }
      }
    }
  } catch (e) {
    // Gracefully handle missing primary medallion
  }

  const descSize = 10;
  const maxLineWidth = width - 100;
  const descWords = data.description.split(' ');
  let descLines: string[] = [];
  let currentLine = '';

  for (const word of descWords) {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    const testWidth = helvetica.widthOfTextAtSize(testLine, descSize);
    if (testWidth > maxLineWidth) {
      if (currentLine) descLines.push(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  }
  if (currentLine) descLines.push(currentLine);

  let yPos = height - 430;
  for (const line of descLines) {
    const lineWidth = helvetica.widthOfTextAtSize(line, descSize);
    page.drawText(line, {
      x: (width - lineWidth) / 2,
      y: yPos,
      size: descSize,
      font: helvetica,
      color: rgb(0.42, 0.42, 0.42),
    });
    yPos -= 15;
  }

  const today = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  const awardedText = `Awarded: ${today}`;
  const awardedWidth = helvetica.widthOfTextAtSize(awardedText, 10);
  page.drawText(awardedText, {
    x: (width - awardedWidth) / 2,
    y: height - 460,
    size: 10,
    font: helvetica,
    color: rgb(0.42, 0.42, 0.42),
  });

  const lineY = 95;
  const leftLineStart = 130;
  const leftLineEnd = 330;
  const rightLineStart = 462;
  const rightLineEnd = 662;

  page.drawLine({
    start: { x: leftLineStart, y: lineY },
    end: { x: leftLineEnd, y: lineY },
    thickness: 0.5,
    color: rgb(0.4, 0.4, 0.4),
  });

  const issuerNameWidth = helvetica.widthOfTextAtSize(data.issuedBy, 9);
  page.drawText(data.issuedBy, {
    x: (leftLineStart + leftLineEnd) / 2 - issuerNameWidth / 2,
    y: 80,
    size: 9,
    font: helvetica,
    color: rgb(0.3, 0.3, 0.3),
  });

  page.drawLine({
    start: { x: rightLineStart, y: lineY },
    end: { x: rightLineEnd, y: lineY },
    thickness: 0.5,
    color: rgb(0.4, 0.4, 0.4),
  });

  const managerTitle = 'Sales Manager';
  const managerWidth = helvetica.widthOfTextAtSize(managerTitle, 9);
  page.drawText(managerTitle, {
    x: (rightLineStart + rightLineEnd) / 2 - managerWidth / 2,
    y: 80,
    size: 9,
    font: helvetica,
    color: rgb(0.3, 0.3, 0.3),
  });

  const verifyText = `Verification: ${data.verificationCode}`;
  const verifyWidth = helvetica.widthOfTextAtSize(verifyText, 7);
  page.drawText(verifyText, {
    x: (width - verifyWidth) / 2,
    y: 50,
    size: 7,
    font: helvetica,
    color: rgb(0.7, 0.7, 0.7),
  });

  const pdfBytes = await pdfDoc.save();
  return Buffer.from(pdfBytes);
}

export async function checkCertificateEligibility(userId: string): Promise<string[]> {
  const eligible: string[] = [];
  const existingCerts = await storage.getCertificatesForUser(userId);
  const existingTypes = new Set(existingCerts.map(c => c.certificateType));

  if (!existingTypes.has('presentation_mastery')) {
    try {
      const progress = await storage.getUserPresentationProgress(userId);
      const completedLessons = progress.filter((p: any) => p.completed).length;
      if (completedLessons >= 24) {
        eligible.push('presentation_mastery');
      }
    } catch (e) { /* ignore */ }
  }

  if (!existingTypes.has('equipiq_expert')) {
    try {
      const quizResults = await storage.getEquipmentQuizResults(userId);
      if (quizResults.length >= 20) {
        const avgScore = quizResults.reduce((sum: number, r: any) => sum + r.score, 0) / quizResults.length;
        if (avgScore >= 80) {
          eligible.push('equipiq_expert');
        }
      }
    } catch (e) { /* ignore */ }
  }

  if (!existingTypes.has('roleplay_champion')) {
    try {
      const sessions = await storage.getRoleplaySessionsByAgent(userId);
      const completedSessions = sessions.filter(s => s.status === 'completed' && s.performanceScore != null);
      if (completedSessions.length >= 30) {
        const avgScore = completedSessions.reduce((sum, s) => sum + (s.performanceScore || 0), 0) / completedSessions.length;
        if (avgScore >= 75) {
          eligible.push('roleplay_champion');
        }
      }
    } catch (e) { /* ignore */ }
  }

  if (!existingTypes.has('sales_excellence')) {
    try {
      const badges = await storage.getBadgesForUser(userId);
      const goldOrHigher = badges.filter(b => b.badgeLevel >= 3);
      const uniqueCategories = new Set(goldOrHigher.map(b => b.category));
      if (uniqueCategories.size >= 3) {
        eligible.push('sales_excellence');
      }
    } catch (e) { /* ignore */ }
  }

  const LADDER_CERT_MAP = [
    { badgeId: 'ladder_level_1', certType: 'ladder_field_scout' },
    { badgeId: 'ladder_level_2', certType: 'ladder_pipeline_builder' },
    { badgeId: 'ladder_level_3', certType: 'ladder_deal_closer' },
    { badgeId: 'ladder_level_4', certType: 'ladder_revenue_generator' },
    { badgeId: 'ladder_level_5', certType: 'ladder_residual_architect' },
  ];

  try {
    const ladderBadges = await storage.getBadgesForUser(userId);
    const ladderLevelBadges = ladderBadges.filter((b: any) => b.category === 'progression_ladder');

    for (const mapping of LADDER_CERT_MAP) {
      if (!existingTypes.has(mapping.certType)) {
        const hasBadge = ladderLevelBadges.some((b: any) => b.badgeId === mapping.badgeId);
        if (hasBadge) {
          eligible.push(mapping.certType);
        }
      }
    }
  } catch (e) { /* ignore */ }

  return eligible;
}
